<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation>Bonjour</translation>
    </message>
</context>
<context>
    <name>Internetconnexionerror</name>
    <message>
        <location filename="QBano_dialog.py" line="168"/>
        <source>Internet connexion error</source>
        <translatorcomment>Erreur de connection internet</translatorcomment>
        <translation>Erreur de connection internet</translation>
    </message>
</context>
<context>
    <name>QBAN(O)</name>
    <message>
        <location filename="QBano_dialog.py" line="168"/>
        <source>QBAN(O)</source>
        <translation>QBAN(O)</translation>
    </message>
</context>
<context>
    <name>QBano</name>
    <message>
        <location filename="QBano.py" line="175"/>
        <source>&amp;QBAN(O)</source>
        <translatorcomment>QBAN(O)</translatorcomment>
        <translation>QBAN(O)</translation>
    </message>
    <message>
        <location filename="QBano.py" line="165"/>
        <source>QBAN(O)</source>
        <translation>QBAN(O)</translation>
    </message>
</context>
<context>
    <name>QBanoDialogBase</name>
    <message>
        <location filename="QBano_dialog_base.ui" line="52"/>
        <source>Layer to Geocode</source>
        <translation>Couche à géocoder</translation>
    </message>
    <message>
        <location filename="QBano_dialog_base.ui" line="68"/>
        <source>Load Project layers</source>
        <translation>Lecture des couches du projet</translation>
    </message>
    <message>
        <location filename="QBano_dialog_base.ui" line="91"/>
        <source>Address field</source>
        <translation>Champ d&apos;adresse</translation>
    </message>
    <message>
        <location filename="QBano_dialog_base.ui" line="107"/>
        <source>Geocode</source>
        <translation>Géocoder</translation>
    </message>
    <message>
        <location filename="QBano_dialog_base.ui" line="14"/>
        <source>QBAN(O)</source>
        <translation>QBAN(O)</translation>
    </message>
</context>
</TS>
